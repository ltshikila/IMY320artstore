# IMY320artstore
 
Note: Please ensure you have installed <code><a href="https://nodejs.org/en/download/">nodejs</a></code>

  1) In the terminal, run `npm install`
  2) Run `npm start` to start local server and database connection
  3) Run login.html on browser
  